#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <stdint.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <time.h>
#include "ch341_lib.h"


#ifndef CH34x_DEBUG
#define CH34x_DEBUG
#endif

#ifdef CH34x_DEBUG
#define dbg( format, arg...)	printf( format "\n", ##arg );
#endif
#define err( format, arg... )	\
	printf( "error %d: " format "\n", __LINE__, ##arg )

int dev_fd = -1;
int sn_length = 12;
char write_sn_str[] = "";
char Read_Buf[64] = {0};

bool CH347_I2C_Init()
{
	bool ret = false;
	int imode = 2;
	// Init CH347 I2C
	//	Imode: 0:20khz 1:100khz 2:400khz 3:750khz
	ret = CH347I2C_Set(dev_fd, imode);	// The IIC speed set 400K
	if (!ret) {
		err("Failed to init I2C");
		return false;
	}

	return true;
}

bool EEPROM_Write()
{
	int i = 0;
	uint8_t DBuf[64] = {0};
	bool RetVal = false;

	stpcpy(DBuf, write_sn_str);
	RetVal = CH347WriteEEPROM(dev_fd, ID_24C02, 0, sn_length, DBuf);
	return RetVal;
}

bool EEPROM_Read()
{
	int i = 0;
	bool RetVal = false;

	RetVal = CH347ReadEEPROM(dev_fd, ID_24C02, 0, sn_length, Read_Buf);
	Read_Buf[sn_length] = '\0'; // maybe the function issue
	printf("Read the SN length: %ld\n", strlen(Read_Buf));
	printf("Read the SN info: %s\n", Read_Buf);
	return RetVal;
}


int main(int argc, char *argv[])
{
	int i = argc;
	int ret = -1;
	if (i <= 2) {
		printf("Need input more parameter.\n");
		printf("The usage: %s <driver ID> <type> [<SN>]\n", argv[0]);
		printf("<driver ID>:\n    The X in /dev/ch34x_pisX\n<type>:\n    0:read SN  1:write SN\n[<SN>]:\n    adapt's SN length is %d\n", sn_length);
        return -1;
	}
	int type = atoi(argv[2]);
	char dev_id[25]={"/dev/ch34x_pis"};
	strcat(dev_id, argv[1]);
	
	if ((i == 3) && (type == 1)) {
		printf("Need input more parameter for write SN!!\n");
		return -1;
	}
	if ((i == 4) && (type == 1)){
		if (strlen(argv[3]) != sn_length) {
			printf("Please enter the correct SN, SN length is %d!!\n", sn_length);
			return -1;
		}
		else {
			strcpy(write_sn_str, argv[3]);
			printf("%s: Write SN to %s\n", dev_id, write_sn_str);
		}
	}
	
    dev_fd = CH347OpenDevice(dev_id);
    if (dev_fd <= 0) {
        printf("Failed to open device.\n");
        return -1;
    }
	
	ret = CH347_I2C_Init();
    if (!ret) {
        err("Failed to init CH347 I2C.");
        exit(-1);
    }
	
	// read SN
	if (type == 0) {
		ret = EEPROM_Read();
		if (!ret) {
			err("============read eeprom fail.\n");
			exit(-1);
		}
	}
	if (type == 1) {
		ret = EEPROM_Write();
		if (!ret) 
		{
			err("============write eeprom fail.\n");
			exit(-1);
		}
		
		ret = EEPROM_Read();
		if (!ret) 
		{
			err("============read eeprom fail.\n");
			exit(-1);
		}

		ret = strcmp(write_sn_str, Read_Buf);
		if (ret == 0)
			printf("Write SN success\n");
		else
			err("============After write eeprom, read data is not same as write.\n");
			exit(-1);
	}
    // Close the CH347 Device
	CH347CloseDevice(dev_fd);
	return 0;
}
