#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <stdint.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <time.h>
#include "ch347_lib.h"
#include <linux/byteorder/little_endian.h>
#include <linux/hidraw.h>

#ifndef CH34x_DEBUG
#define CH34x_DEBUG
#endif

#ifdef CH34x_DEBUG
#define dbg( format, arg...)	printf( format "\n", ##arg );
#endif
#define err( format, arg... )	\
	printf( "error %d: " format "\n", __LINE__, ##arg )

int dev_fd = -1;
static struct timeval t1, t2;

bool CH347_I2C_Init()
{
	int ret = -1;
	int imode = 2;
	// Init CH347 I2C
	//	Imode: 0:20khz 1:100khz 2:400khz 3:750khz
	ret = CH347I2C_Set(dev_fd, imode);	// The IIC speed set 400K
	if (!ret) {
		err("Failed to init I2C");
		return false;
	}

	return true;
}

bool IIC_Set_On()
{
//	0XE0 0x03 1 0x00       //配置IO为output
//	0XE0 0x01 1 0x8F       //配置IO口为高电平
	int i = 0;
	int WriteDataLen = 3;
	int ReadDataLen = 8;
	uint8_t opBuf[2] = {0};
	uint8_t onBuf[2] = {0};
	uint8_t RDBuf[8] = {0};

	bool RetVal = false;
	//配置IO为output
	opBuf[0] = 0xe0;
	opBuf[1] = 0x03;
	opBuf[2] = 0x00;

	
	printf("Write  data: ");
	for (i = 0; i < WriteDataLen; i++)
	{
		printf("%02x ", opBuf[i]);
	}
	printf("\n");

	RetVal = CH347StreamI2C(dev_fd,WriteDataLen,opBuf,ReadDataLen,RDBuf);
	if (!RetVal) {
        err("Failed to set CH347 I2C output.");
    }
	
	//配置IO口为高电平
	onBuf[0] = 0xe0;
	onBuf[1] = 0x01;
	onBuf[2] = 0x8f;
	printf("Write  data: ");
	for (i = 0; i < WriteDataLen; i++)
	{
		printf("%02x ", onBuf[i]);
	}
	printf("\n");

	RetVal = CH347StreamI2C(dev_fd,WriteDataLen,onBuf,ReadDataLen,RDBuf);
	if (!RetVal) {
        err("Failed to set CH347 I2C PF On.");
    }
	return RetVal;
}

bool IIC_Set_Off()
{
//	0XE0 0x03 1 0x00       //配置IO为output
//	0XE0 0x01 1 0x0F       //配置IO口为低电平
	int i = 0;
	int WriteDataLen = 3;
	int ReadDataLen = 8;
	uint8_t opBuf[2] = {0};
	uint8_t offBuf[2] = {0};
	uint8_t RDBuf[8] = {0};

	bool RetVal = false;
	//配置IO为output
	opBuf[0] = 0xe0;
	opBuf[1] = 0x03;
	opBuf[2] = 0x00;
	
	printf("Write  data: ");
	for (i = 0; i < WriteDataLen; i++)
	{
		printf("%02x ", opBuf[i]);
	}
	printf("\n");

	RetVal = CH347StreamI2C(dev_fd,WriteDataLen,opBuf,ReadDataLen,RDBuf);
	if (!RetVal) {
        err("Failed to set CH347 I2C output.");
    }
	
	//配置IO口为低电平
	offBuf[0] = 0xe0;
	offBuf[1] = 0x01;
	offBuf[2] = 0x0f;
	printf("Write  data: ");
	for (i = 0; i < WriteDataLen; i++)
	{
		printf("%02x ", offBuf[i]);
	}
	printf("\n");

	RetVal = CH347StreamI2C(dev_fd,WriteDataLen,offBuf,ReadDataLen,RDBuf);
	if (!RetVal) {
        err("Failed to set CH347 I2C PF Off.");
    }
	return RetVal;
}

int main(int argc, char *argv[])
{
	int i = argc;
	if (i <= 2) {
		printf("Need input more parameter.\n");
		printf("The usage: %s <driver ID> <status>\n", argv[0]);
		printf("<driver ID>:\n    The X in /dev/ch34x_pisX\n<status>:\n    0:relay off 1:relay on\n");
        return -1;
	}

	int status = atoi(argv[2]);
	int ret = -1;
	char dev_id[25]={"/dev/ch34x_pis"};
	strcat(dev_id, argv[1]);
	
	// Open the device
	// dev_fd = open("/dev/hidraw2", O_RDWR);
    dev_fd = CH347OpenDevice(dev_id);
    if (dev_fd <= 0) {
        printf("Failed to open device.\n");
        return -1;
    }
	
	ret = CH347_I2C_Init();
    if (!ret) {
        err("Failed to init CH347 I2C.");
        exit(-1);
    }
	if (status == 0)
	{
		ret = IIC_Set_Off();
		if (!ret) 
		{
			err("Failed to set power off by CH347 I2C.\n");
			exit(-1);
		}
		else
		{
			printf("Success to set power off by CH347 I2C.\n");
		}
	}
	if (status == 1)
	{
		ret = IIC_Set_On();
		if (!ret) 
		{
			err("Failed to set power on by CH347 I2C.\n");
			exit(-1);
		}
		else
		{
			printf("Success to set power on by CH347 I2C.\n");
		}
	}
    // Close the CH347 Device
	CH347CloseDevice(dev_fd);


	return 0;
}